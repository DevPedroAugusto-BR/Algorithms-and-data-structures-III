#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define MAX_CITIES 10000

typedef struct {
    int x;
    int y;
} City;

// Funções auxiliares...
double distance(City city1, City city2);
double route_distance(int route[], City cities[], int n);
void swap(int *a, int *b);
void shuffle(int array[], int n);
void random_route(int route[], int n);
void print_route(int route[], int n);
void reverse_segment(int route[], int start, int end);
int read_cities(const char *filename, City cities[]);
void save_route(const char *filename, int route[], City cities[], int n, const char *type);
void local_search(int route[], City cities[], int n);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Uso: %s <arquivo_instancia>\n", argv[0]);
        return 1;
    }

    srand(time(NULL));

    City cities[MAX_CITIES];
    int num_cities = read_cities(argv[1], cities);

    if (num_cities <= 0) {
        fprintf(stderr, "Erro ao ler o arquivo de cidades.\n");
        return 1;
    }

    int best_iteration = 0; // Inicialize a variável best_iteration fora do loop

    for (int iteration = 1; iteration <= 3; iteration++) {
        printf("Iteracao %d:\n", iteration);

        clock_t start_time, end_time;
        double total_time;

        int initial_route[num_cities];
        random_route(initial_route, num_cities);
        printf("Rota inicial: ");
        print_route(initial_route, num_cities);
        printf("Distancia inicial: %.2f\n", route_distance(initial_route, cities, num_cities));

        start_time = clock(); // Inicia a contagem do tempo

        local_search(initial_route, cities, num_cities);

        end_time = clock(); // Finaliza a contagem do tempo
        total_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

        printf("Rota otimizada: ");
        print_route(initial_route, num_cities);
        printf("Distancia otimizada: %.2f\n", route_distance(initial_route, cities, num_cities));

        printf("Tempo de execucao: %.4f segundos\n\n", total_time);

        // Salva a rota otimizada apenas se for a melhor encontrada até agora
        if (best_iteration == 0 || iteration < best_iteration) {
            best_iteration = iteration;
            save_route("rota_otimizada.txt", initial_route, cities, num_cities, "Otimizada");
            printf("Rota otimizada salva em 'rota_otimizada.txt' (Iteracao %d).\n", best_iteration);
        }
    }
     system("python plot_routes.py");

    return 0;
}

double distance(City city1, City city2) {
    return sqrt(pow(city2.x - city1.x, 2) + pow(city2.y - city1.y, 2));
}

double route_distance(int route[], City cities[], int n) {
    double total_distance = 0;
    for (int i = 0; i < n - 1; i++) {
        total_distance += distance(cities[route[i]], cities[route[i + 1]]);
    }
    total_distance += distance(cities[route[n - 1]], cities[route[0]]);
    return total_distance;
}

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void shuffle(int array[], int n) {
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        swap(&array[i], &array[j]);
    }
}

void random_route(int route[], int n) {
    for (int i = 0; i < n; i++) {
        route[i] = i;
    }
    shuffle(route, n);
}

void print_route(int route[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", route[i]);
    }
    printf("\n");
}

void reverse_segment(int route[], int start, int end) {
    while (start < end) {
        swap(&route[start], &route[end]);
        start++;
        end--;
    }
}

void local_search(int route[], City cities[], int n) {
    double initial_distance = route_distance(route, cities, n);
    int improvements;

    // Implementação da busca local (2-opt)
    do {
        improvements = 0;
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                reverse_segment(route, i, j);
                double new_distance = route_distance(route, cities, n);
                if (new_distance < initial_distance) {
                    initial_distance = new_distance;
                    improvements++;
                } else {
                    reverse_segment(route, i, j); // Desfazer a reversão
                }
            }
        }
    } while (improvements > 0);
}

int read_cities(const char *filename, City cities[]) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Erro ao abrir o arquivo");
        return -1;
    }

    int num_cities = 0;
    while (fscanf(file, "%d %d", &cities[num_cities].x, &cities[num_cities].y) == 2) {
        num_cities++;
        if (num_cities >= MAX_CITIES) {
            break;
        }
    }

    fclose(file);
    return num_cities;
}

void save_route(const char *filename, int route[], City cities[], int n, const char *type) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Erro ao abrir o arquivo");
        return;
    }

    fprintf(file, "%s\n", type);
    for (int i = 0; i < n; i++) {
        fprintf(file, "%d %d %d\n", route[i], cities[route[i]].x, cities[route[i]].y);
    }

    fclose(file);
}
