#gera cidades miugral
import random
import sys

def main():
    # Check if the number of cities is provided as an argument
    if len(sys.argv) != 2:
        print("Usage: python file.py <num_cities>")
        return

    # Get the number of cities from the command line argument
    num_cities = int(sys.argv[1])

    # Generate random coordinates for the cities
    cities = [(random.randint(0, 1000), random.randint(0, 1000)) for _ in range(num_cities)]

    # Define the file path
    output_file_path = f'auto_tsp{num_cities}.txt'

    # Write the coordinates to the file
    with open(output_file_path, 'w') as file:
        for x, y in cities:
            file.write(f"{x} {y}\n")

    print(f"File '{output_file_path}' created with {num_cities} cities.")

if __name__ == "__main__":
    main()
