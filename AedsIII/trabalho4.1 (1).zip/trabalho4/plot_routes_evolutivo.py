import matplotlib.pyplot as plt

def plot_route_from_file(filename):
    with open(filename, 'r') as file:
        next(file)  # Ignorar a primeira linha (Otimizada)
        lines = file.readlines()
        indices = [int(line.split()[0]) for line in lines]
        x = [int(line.split()[1]) for line in lines]
        y = [int(line.split()[2]) for line in lines]
    
    plt.plot(x, y, marker='o', markerfacecolor='red', markersize=8, linestyle='-', color='blue', label='Rota')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.title('Rota Otimizada')
    
    # Marcar a primeira e última cidade
    plt.plot(x[0], y[0], marker='o', markersize=8, color='green', markerfacecolor='green', label='Início')
    plt.text(x[0], y[0], str(indices[0]), fontsize=9, ha='right', color='green')
    
    plt.plot(x[-1], y[-1], marker='o', markersize=8, color='yellow', markerfacecolor='yellow', label='Fim')
    plt.text(x[-1], y[-1], str(indices[-1]), fontsize=9, ha='right', color='yellow')
    
    # Adicionando índices como texto em cada bolinha do gráfico
    for i, txt in enumerate(indices):
        plt.text(x[i], y[i], str(txt), fontsize=9, ha='right', color='black')
    
    plt.legend()
    plt.show()

plot_route_from_file('rota_otimizada_evolutivo.txt')
