import matplotlib.pyplot as plt

def read_optimized_route(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()[1:]  # Ignora a primeira linha
        coords = []
        indices = []
        for line in lines:
            index, x, y = map(int, line.split())
            coords.append((x, y))
            indices.append(index)
    return coords, indices

def plot_route(coords, indices):
    x = [coord[0] for coord in coords]
    y = [coord[1] for coord in coords]

    plt.plot(x, y, marker='o', linestyle='-')
    plt.title('Rota Otimizada')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.grid(True)

    # Marcar o ponto de entrada e saída
    plt.plot(x[0], y[0], marker='o', color='green', markersize=10, label='Ponto de Partida')
    plt.plot(x[-1], y[-1], marker='o', color='red', markersize=10, label='Ponto de Chegada')

    # Adiciona o índice de cada cidade como texto
    for i in range(len(coords)):
        plt.text(x[i], y[i], str(indices[i]), color='blue', fontsize=10)

    # Adiciona as conexões entre as cidades
    for i in range(len(coords) - 1):
        plt.plot([x[i], x[i+1]], [y[i], y[i+1]], color='black', linestyle='--')

    plt.legend()
    plt.show()

# Suponha que você salvou a rota otimizada em um arquivo chamado 'rota_otimizada.txt'
optimized_route, city_indices = read_optimized_route('rota_otimizada.txt')    
plot_route(optimized_route, city_indices)
