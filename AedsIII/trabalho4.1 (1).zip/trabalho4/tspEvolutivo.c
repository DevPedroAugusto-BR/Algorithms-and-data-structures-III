// Title: Evolutivo Caixeiro Viajante
// Disciplina: Algoritmos e Estruturas de Dados III
// Prodessor: Iago Augusto de Carvalho
// Alunos:
// José Argemiro dos Reis Neto (2021.1.08.011)
// Otávio Augusto Marcelino Izidoro (2018.1.08.041)
// Pedro Augusto Mendes (2021.1.08.041)
// Rikson Pablo Gomes da Rocha (2022.2.08.007)
// Victor Ribeiro Gonçalez (2021.1.08.023)
// Objetivo: Implementar um algoritmo evolutivo para resolver o problema do caixeiro viajante (TSP) e aplicá-lo a um conjunto de instâncias de teste.
// Execução: Para executar o programa, basta compilar e executar o arquivo gerado. Com isso se voce estiver utlizando o windows basta rodar este primeiro comando no terminal: mingw32-make.exe
// Em seguida, execute o arquivo gerado: ./tsp_evolutivo <arquivo_instancia>

// Data: 29/05/2024

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>

#define MAX_CITIES 100
#define POPULATION_SIZE 50
#define NUM_GENERATIONS 1000
#define MUTATION_RATE 0.1

typedef struct
{
    int x;
    int y;
} City;

typedef struct
{
    int route[MAX_CITIES];
    double fitness;
} Individual;

// Funções auxiliares...
void swap(int *a, int *b);
void random_route(int route[], int n);
void print_route(int route[], int n);
double distance(City city1, City city2);
double route_distance(int route[], City cities[], int n);
void initialize_population(Individual population[], int num_cities);
void evaluate_population(Individual population[], City cities[], int num_cities);
void crossover(Individual population[], int num_cities);
void mutate(Individual population[], int num_cities);
int roulette_wheel_selection(Individual population[], int population_size);
void print_best_solution(Individual *solution, int num_cities);

int read_tsp(const char *filename, City cities[]);
void genetic_algorithm(City cities[], int num_cities);

void save_route_to_file(Individual *solution, City cities[], int num_cities, const char *filename);

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        fprintf(stderr, "Uso: %s <arquivo_instancia>\n", argv[0]);
        return 1;
    }

    srand(time(NULL));

    City cities[MAX_CITIES];
    int num_cities = read_tsp(argv[1], cities);

    if (num_cities <= 0)
    {
        fprintf(stderr, "Erro ao ler o arquivo TSP.\n");
        return 1;
    }

    printf("Rota inicial:\n");
    for (int i = 0; i < num_cities; i++) {
        printf("%d %d\n", cities[i].x, cities[i].y);
    }

    clock_t start_time, end_time;
    double total_time;

    for (int i = 0; i < 3; i++)
    {
        printf("Iteracao %d:\n", i + 1);
        start_time = clock();
        genetic_algorithm(cities, num_cities);
        end_time = clock();
        total_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;
        printf("Tempo de execucao: %.4f segundos\n", total_time);
        printf("\n");
    }

    return 0;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

void random_route(int route[], int n)
{
    for (int i = 0; i < n; i++)
    {
        route[i] = i;
    }
    for (int i = n - 1; i > 0; i--)
    {
        int j = rand() % (i + 1);
        swap(&route[i], &route[j]);
    }
}

void print_route(int route[], int n)
{
    for (int i = 0; i < n; i++)
    {
        printf("%d ", route[i]);
    }
    printf("\n");
}

double distance(City city1, City city2)
{
    return sqrt(pow(city2.x - city1.x, 2) + pow(city2.y - city1.y, 2));
}

double route_distance(int route[], City cities[], int n)
{
    double total_distance = 0;
    for (int i = 0; i < n - 1; i++)
    {
        total_distance += distance(cities[route[i]], cities[route[i + 1]]);
    }
    total_distance += distance(cities[route[n - 1]], cities[route[0]]);
    return total_distance;
}

int read_tsp(const char *filename, City cities[])
{
    FILE *file = fopen(filename, "r");
    if (file == NULL)
    {
        perror("Erro ao abrir o arquivo");
        return -1;
    }

    int num_cities = 0;
    while (fscanf(file, "%d %d", &cities[num_cities].x, &cities[num_cities].y) == 2)
    {
        num_cities++;
        if (num_cities >= MAX_CITIES)
        {
            break;
        }
    }

    fclose(file);
    return num_cities;
}

void initialize_population(Individual population[], int num_cities)
{
    for (int i = 0; i < POPULATION_SIZE; i++)
    {
        random_route(population[i].route, num_cities);
    }
}

void evaluate_population(Individual population[], City cities[], int num_cities)
{
    for (int i = 0; i < POPULATION_SIZE; i++)
    {
        population[i].fitness = route_distance(population[i].route, cities, num_cities);
    }
}

void crossover(Individual population[], int num_cities)
{
    for (int i = 0; i < POPULATION_SIZE; i++)
    {
        int parent1 = roulette_wheel_selection(population, POPULATION_SIZE);
        int parent2 = roulette_wheel_selection(population, POPULATION_SIZE);

        int start = rand() % num_cities;
        int end = rand() % num_cities;

        if (start > end)
        {
            swap(&start, &end);
        }

        int child[num_cities];
        memset(child, -1, sizeof(child));

        // Copiar a parte da rota do parent1 para o filho
        for (int j = start; j <= end; j++)
        {
            child[j] = population[parent1].route[j];
        }

        // Preencher o resto do filho com cidades do parent2
        int idx = 0;
        for (int j = 0; j < num_cities; j++)
        {
            if (idx == start)
            {
                idx = end + 1;
            }

            // Se a cidade ainda não estiver no filho, adicione-a
            if (!contains(child, num_cities, population[parent2].route[j]))
            {
                while (child[idx] != -1)
                {
                    idx = (idx + 1) % num_cities;
                }
                child[idx] = population[parent2].route[j];
            }
        }

        // Copiar o filho de volta para a população
        memcpy(population[i].route, child, sizeof(child));
    }
}

// Verifica se uma cidade está presente em uma rota
int contains(int route[], int num_cities, int city)
{
    for (int i = 0; i < num_cities; i++)
    {
        if (route[i] == city)
        {
            return 1;
        }
    }
    return 0;
}

void mutate(Individual population[], int num_cities)
{
    for (int i = 0; i < POPULATION_SIZE; i++)
    {
        if ((double)rand() / RAND_MAX < MUTATION_RATE)
        {
            int idx1 = rand() % num_cities;
            int idx2 = rand() % num_cities;
            swap(&population[i].route[idx1], &population[i].route[idx2]);
        }
    }
}

int roulette_wheel_selection(Individual population[], int population_size)
{
    double total_fitness = 0;
    for (int i = 0; i < population_size; i++)
    {
        total_fitness += 1.0 / population[i].fitness;
    }

    double random_value = (double)rand() / RAND_MAX;
    double sum = 0;
    for (int i = 0; i < population_size; i++)
    {
        sum += 1.0 / population[i].fitness / total_fitness;
        if (sum >= random_value)
        {
            return i;
        }
    }

    return population_size - 1;
}

void print_best_solution(Individual *solution, int num_cities)
{
    printf("Rota otimizada:\n");
    print_route(solution->route, num_cities);
    printf("Distancia otimizada: %.2f\n", solution->fitness);
}

void save_route_to_file(Individual *solution, City cities[], int num_cities, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Erro ao abrir o arquivo");
        return;
    }
    
    fprintf(file, "Otimizada\n");
    for (int i = 0; i < num_cities; i++) {
        int city_index = solution->route[i];
        fprintf(file, "%d %d %d\n", city_index, cities[city_index].x, cities[city_index].y);
    }
    
    fclose(file);
}

void genetic_algorithm(City cities[], int num_cities)
{
    Individual population[POPULATION_SIZE];
    Individual best_solution;
    initialize_population(population, num_cities);
    evaluate_population(population, cities, num_cities);

    clock_t start_time = clock();

    for (int generation = 0; generation < NUM_GENERATIONS; generation++)
    {
        crossover(population, num_cities);
        mutate(population, num_cities);
        evaluate_population(population, cities, num_cities);

        // Encontra a melhor solução na população
        best_solution = population[0];
        for (int i = 1; i < POPULATION_SIZE; i++)
        {
            if (population[i].fitness < best_solution.fitness)
            {
                best_solution = population[i];
            }
        }
    }

    clock_t end_time = clock();
    double total_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

    // Salva a melhor solução em um arquivo
    save_route_to_file(&best_solution, cities, num_cities, "rota_otimizada_evolutivo.txt");
     
    printf("Melhor solucao encontrada:\n");
    print_best_solution(&best_solution, num_cities);
    printf("Tempo de execucao: %.4f segundos\n", total_time);
    system("python plot_routes_evolutivo.py");
}
